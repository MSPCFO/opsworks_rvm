# frozen_string_literal: true
#
# Cookbook Name:: mspcfo
# Recipe:: deploy
#

include_recipe 'opsworks_ruby::deploy'