# frozen_string_literal: true
#
# Cookbook Name:: mspcfo
# Recipe:: shutdown
#

include_recipe 'opsworks_ruby::shutdown'
